package com.entity.layer2;

import java.util.List;

import com.entity.layer1.Admininput;

public interface AdmininputRepository {
	void save(Admininput admininputs);
	List<Admininput> getAdminById(String adminuserid);
	
	List<Admininput> getAdminByIdAndPassword(String adminuserid, String adminpassword);
	
}

